import Image from 'next/image';
import React, { useEffect, useRef, useState } from 'react';

const OBJECTIVE = [
  {
    id: 1,
    image:
      'https://cdn-icbnj.nitrocdn.com/DxLMbDkMAsFVFzgPzCObWFuipKtAgITG/assets/images/optimized/rev-81f18f1/www.unifiedinfotech.net/wp-content/themes/unifiedinfotech/assets/images/jira1@2x.webp',
  },
  {
    id: 2,
    image:
      'https://cdn-icbnj.nitrocdn.com/DxLMbDkMAsFVFzgPzCObWFuipKtAgITG/assets/images/optimized/rev-81f18f1/www.unifiedinfotech.net/wp-content/themes/unifiedinfotech/assets/images/slack1@2x-144x23.webp',
  },
  {
    id: 3,
    image:
      'https://cdn-icbnj.nitrocdn.com/DxLMbDkMAsFVFzgPzCObWFuipKtAgITG/assets/images/optimized/rev-81f18f1/www.unifiedinfotech.net/wp-content/themes/unifiedinfotech/assets/images/github@2x-144x23.webp',
  },
  {
    id: 4,
    image:
      'https://cdn-icbnj.nitrocdn.com/DxLMbDkMAsFVFzgPzCObWFuipKtAgITG/assets/images/optimized/rev-81f18f1/www.unifiedinfotech.net/wp-content/themes/unifiedinfotech/assets/images/asana1@2x-144x23.webp',
  },
  {
    id: 5,
    image:
      'https://cdn-icbnj.nitrocdn.com/DxLMbDkMAsFVFzgPzCObWFuipKtAgITG/assets/images/optimized/rev-81f18f1/www.unifiedinfotech.net/wp-content/themes/unifiedinfotech/assets/images/invision@2x-144x23.webp',
  },
  {
    id: 6,
    image:
      'https://cdn-icbnj.nitrocdn.com/DxLMbDkMAsFVFzgPzCObWFuipKtAgITG/assets/images/optimized/rev-81f18f1/www.unifiedinfotech.net/wp-content/themes/unifiedinfotech/assets/images/axure@2x-144x23.webp',
  },
  {
    id: 7,
    image:
      'https://cdn-icbnj.nitrocdn.com/DxLMbDkMAsFVFzgPzCObWFuipKtAgITG/assets/images/optimized/rev-81f18f1/www.unifiedinfotech.net/wp-content/themes/unifiedinfotech/assets/images/zeplin@2x-144x23.webp',
  },
  {
    id: 8,
    image:
      'https://cdn-icbnj.nitrocdn.com/DxLMbDkMAsFVFzgPzCObWFuipKtAgITG/assets/images/optimized/rev-81f18f1/www.unifiedinfotech.net/wp-content/themes/unifiedinfotech/assets/images/office365@2x-144x23.webp',
  },
  {
    id: 9,
    image:
      'https://cdn-icbnj.nitrocdn.com/DxLMbDkMAsFVFzgPzCObWFuipKtAgITG/assets/images/optimized/rev-81f18f1/www.unifiedinfotech.net/wp-content/themes/unifiedinfotech/assets/images/zoom1@2x-144x23.webp',
  },
  {
    id: 10,
    image:
      'https://cdn-icbnj.nitrocdn.com/DxLMbDkMAsFVFzgPzCObWFuipKtAgITG/assets/images/optimized/rev-81f18f1/www.unifiedinfotech.net/wp-content/themes/unifiedinfotech/assets/images/skype1@2x-144x23.webp',
  },
];

const Collaboration = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const handleScroll = () => {
      if (section && !isVisible) {
        const top = section.getBoundingClientRect().top;
        const windowHeight = window.innerHeight;
        if (top < windowHeight * 0.8) {
          setIsVisible(true);
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [isVisible]);
  return (
    <div className="container mx-auto py-24">
      <div
        ref={sectionRef}
        className={`animated-section ${
          isVisible ? 'slideInDown' : ''
        } flex justify-between lg:flex-row flex-col `}
      >
        <div className="flex flex-col text-white px-4">
          <h2 className="text-4xl pb-6">Collaboration Tools</h2>
          <p className="text-lg pb-4">
            We make sure to use the tools that are top of the market to bring
            your ideas into reality. Our careful selection of tools makes sure
            that your ideas are executed with the highest level of efficiency.
          </p>
        </div>
        <div className="flex lg:flex-col flex-row text-white px-4">
          <ul className="flex flex-wrap pb-4 gap-x-14 lg:gap-x-32">
            {OBJECTIVE.map(({ image, id }) => (
              <li
                key={id}
                className="m-4"
              >
                <Image
                  src={image}
                  alt={`Tool ${id}`}
                  width={80}
                  height={23}
                />
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Collaboration;

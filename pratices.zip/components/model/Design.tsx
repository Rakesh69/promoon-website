import FacebookIcon from '@/icons/FacebookIcon';
import InstragramIcon from '@/icons/InstragramIcon';
import LinkedinIcon from '@/icons/LinkedinIcon';
import TwitterIcon from '@/icons/TwitterIcon';
import React from 'react';

const Design = () => {
  const OBJECTIVE = [
    {
      id: 1,
      title:
        'UI Design of all the project screens based on the approved wire-frames and design guidelines',
    },
    {
      id: 2,
      title: 'Web, Tablet and Mobile specific designs.',
    },
    {
      id: 3,
      title: 'Getting system UI Designs approved and confirmed by the client.',
    },
  ];
  const DELIVERABLES = [
    {
      id: 1,
      title: 'UI Designs of the projects',
    },
    {
      id: 2,
      title: 'Clickable prototype on Invision platform -> example link',
    },
    {
      id: 3,
      title: 'Source files in either Photoshop or Sketch format',
    },
  ];
  const TEAM_MEMBERS_INVOLVED = [
    {
      id: 1,
      title: 'Project Manager',
    },
    {
      id: 2,
      title: 'IA & UX Lead',
    },
    {
      id: 3,
      title: 'UI Design Lead',
    },
    {
      id: 4,
      title: 'UI Designer',
    },
  ];
  return (
    <>
      <section id="design">
        <div className="bg-[#F3F4F6] w-full pb-14">
          <h2 className="pt-20 font-bold text-textPrimary text-base mb-4 pl-6 text-bold">
            OBJECTIVE
          </h2>
          <ul className=" pl-12">
            {OBJECTIVE.map(({ title, id }) => (
              <li
                key={id}
                className="text-textPrimary text-lg mb-4 pl-4 list-disc "
              >
                {title}
              </li>
            ))}
          </ul>
        </div>

        <div className=" w-full py-20 lg:px-14">
          <h2 className="lg:pt-20 font-bold text-white text-base mb-4 pl-6 text-bold pt-6 lg:pt-0">
            DELIVERABLES
          </h2>
          <ul className=" pl-12">
            {DELIVERABLES.map(({ title, id }) => (
              <li
                key={id}
                className="text-white text-lg mb-4 pl-4 list-disc "
              >
                {title}
              </li>
            ))}
          </ul>

          <div className=" px-14 pb-8 lg:pb-0">
            <h2 className="pt-10 font-bold text-white text-base mb-2  text-bold">
              Tools
            </h2>
            <div className="flex gap-4 ">
              <LinkedinIcon />
              <InstragramIcon />
              <TwitterIcon />
              <FacebookIcon />
            </div>
          </div>

          <h2 className="lg:pt-20 font-bold text-white text-base mb-4 pl-6 text-bold pt-6 ">
            TEAM_MEMBERS_INVOLVED
          </h2>
          <ul className=" pl-12">
            {TEAM_MEMBERS_INVOLVED.map(({ title, id }) => (
              <li
                key={id}
                className="text-white text-lg mb-4 pl-4 list-disc "
              >
                {title}
              </li>
            ))}
          </ul>
        </div>
      </section>
    </>
  );
};
export default Design;

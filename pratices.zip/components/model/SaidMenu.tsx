import Link from 'next/link';
import React, { useEffect, useState } from 'react';

const NAV_MENUES = [
  { id: 1, menu: '1. Discovery Workshop', path: '#workshop' },
  { id: 2, menu: '2. Planning', path: '#planning' },
  { id: 3, menu: '3. Design', path: '#design' },
  { id: 4, menu: '4. Development', path: '#development' },
  { id: 5, menu: '5. Testing', path: '#testing' },
  { id: 6, menu: '6. Maintenance', path: '#maintenance' },
];

const res_NAV_MENUES = [
  { id: 1, menu: '1', path: '#workshop' },
  { id: 2, menu: '2', path: '#planning' },
  { id: 3, menu: '3', path: '#design' },
  { id: 4, menu: '4', path: '#development' },
  { id: 5, menu: '5', path: '#testing' },
  { id: 6, menu: '6', path: '#maintenance' },
];

const SaidMenu = () => {
  const [active, setActive] = useState<string | null>(null);
  const [lineHeight, setLineHeight] = useState('0%');

  useEffect(() => {
    const handleScroll = () => {
      const sections = document.querySelectorAll('section[id]');
      let found = false;

      sections.forEach((current) => {
        const currentElement = current as HTMLElement;
        const sectionHeight = currentElement.offsetHeight;
        const sectionTop = currentElement.offsetTop - 10;
        const sectionId = current.getAttribute('id');

        if (
          window.pageYOffset > sectionTop &&
          window.pageYOffset <= sectionTop + sectionHeight
        ) {
          if (active !== `#${sectionId}`) {
            setActive(`#${sectionId}`);
            setLineHeight(
              `${
                ((Array.from(sections).indexOf(current) + 1) /
                  sections.length) *
                100
              }%`
            );
          }
          found = true;
        }
      });

      if (!found) {
        setLineHeight('0%');
      }
    };

    const smoothScrollTo = (id: string) => {
      const element = document.querySelector(id);
      if (element) {
        element.scrollIntoView({
          behavior: 'smooth',
          block: 'start',
        });
      }
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [active]);

  useEffect(() => {
    const handleScroll = () => {
      const sidebar = document.getElementById('sidebar');
      const sidebarWrap = document.getElementById('sidebarWrap');
      const footer = document.getElementById('footer');

      if (!sidebar || !sidebarWrap || !footer) return;

      const top =
        sidebarWrap.offsetTop -
        parseFloat(window.getComputedStyle(sidebarWrap).marginTop || '0');
      const footTop =
        footer.offsetTop -
        parseFloat(window.getComputedStyle(footer).marginTop || '0');
      const maxY = footTop - sidebar.offsetHeight;

      const y = window.scrollY;

      if (y > top && y < maxY) {
        sidebar.classList.add('fixed');
        sidebar.style.top = '0';
      } else if (y >= maxY) {
        sidebar.classList.remove('fixed');
        sidebar.style.position = 'absolute';
        sidebar.style.top = `${maxY - top}px`;
      } else {
        sidebar.classList.remove('fixed');
        sidebar.removeAttribute('style');
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  function smoothScrollTo(path: string): void {
    throw new Error('Function not implemented.');
  }

  return (
    <>
      <div
        id="sidebarWrap"
        className="min-w-48 border-blackBlue relative lg:block hidden overflow-hidden h-fit"
      >
        <div
          id="sidebar"
          className="pt-6 xl:pl-60"
        >
          <ul>
            {NAV_MENUES.map(({ id, menu, path }) => (
              <li
                className={`py-10 hover:transition duration-300 dark:text-white text-base font-semibold hover:font-bold ease-in pl-4 ${
                  active === path
                    ? 'dark:text-red-500 font-semibold'
                    : 'text-white'
                }`}
                key={id}
                onClick={() => smoothScrollTo(path)}
              >
                <Link href={path}>
                  <div>{menu}</div>
                </Link>
              </li>
            ))}
          </ul>
          <div>
            <div
              className="absolute h-full bg-blue"
              style={{
                width: '4px',
                top: '0',
                transformOrigin: 'top',
                height: lineHeight,
                transition: 'height 0.3s ease',
              }}
            />
          </div>
        </div>
      </div>

      <div className="lg:hidden flex flex-row justify-center items-center">
        <div className="flex flex-row">
          <ul className="flex flex-row space-x-10">
            {res_NAV_MENUES.map(({ id, menu, path }) => (
              <li
                className={`hover:transition duration-300 dark:text-white text-base text-center font-semibold hover:font-bold ease-in ${
                  active === path ? 'rounded-full bg-blue px-2' : 'text-white'
                }`}
                key={id}
              >
                <Link href={path}>
                  <div>{menu}</div>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </>
  );
};

export default SaidMenu;

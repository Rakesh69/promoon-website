export interface ContactUsType {
    isChecked: boolean;
    firstname: string;
    lastname: string;
    email: string;
    message: string;
}
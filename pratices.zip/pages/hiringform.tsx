import HiringForm from "@/components/HiringForm";

const hiringform = () => {
  return <HiringForm />;
};

export default hiringform;
